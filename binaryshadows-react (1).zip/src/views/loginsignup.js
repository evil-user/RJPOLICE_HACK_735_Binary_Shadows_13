import React from 'react'

import Script from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import './loginsignup.css'

const Loginsignup = (props) => {
  return (
    <div className="loginsignup-container">
      <Helmet>
        <title>loginsignup - BinaryShadows</title>
        <meta property="og:title" content="loginsignup - BinaryShadows" />
      </Helmet>
      <div className="loginsignup-container1">
        <div className="loginsignup-container2">
          <Script
            html={`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crime Reporting App</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        #container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 100%;
            max-width: 500px;
            margin: 20px;
        }

        .tab {
            display: flex;
            justify-content: space-around;
            margin-bottom: 20px;
            background-color: #343a40;
            border-bottom: 2px solid #495057;
        }

        .tab button {
            background-color: #343a40;
            color: #ffffff;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        .tab button:hover {
            background-color: #495057;
        }

        .tab button.active {
            background-color: #495057;
        }

        .form-group {
            padding: 20px;
            box-sizing: border-box;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #495057;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group button {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }

        .form-group .forgot-password {
            text-align: right;
            margin-top: 10px;
        }

        .form-group .forgot-password a {
            color: #007bff;
            text-decoration: none;
        }

        .additional-fields {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100%, 1fr));
            grid-gap: 15px;
        }

        .additional-fields label {
            display: block;
            margin-bottom: 8px;
            color: #495057;
        }
    </style>
</head>
<body>
    <div id="container">
        <div class="tab">
            <button id="loginTab" class="active" onclick="changeTab('login')">Login</button>
            <button id="signupTab" onclick="changeTab('signup')">Sign Up</button>
        </div>
        <div class="form-group" id="loginForm">
            <label for="loginUsername">Username:</label>
            <input type="text" id="loginUsername" placeholder="Enter your username">
            <label for="loginPassword">Password:</label>
            <input type="password" id="loginPassword" placeholder="Enter your password">
            <div class="forgot-password">
                <a href="#">Forgot Password?</a>
            </div>
            <button onclick="login()">Login</button>
        </div>
        <div class="form-group" id="signupForm" style="display: none;">
            <label for="signupFullName">Full Name:</label>
            <input type="text" id="signupFullName" placeholder="Enter your full name">
            <label for="signupUsername">Username:</label>
            <input type="text" id="signupUsername" placeholder="Choose a username">
            <label for="signupPassword">Password:</label>
            <input type="password" id="signupPassword" placeholder="Choose a password">
            <label for="signupPhoneNumber">Phone Number:</label>
            <input type="tel" id="signupPhoneNumber" placeholder="Enter your phone number">
            <label for="signupEmail">Email Address:</label>
            <input type="email" id="signupEmail" placeholder="Enter your email address">
            <label for="signupAddress">Address:</label>
            <input type="text" id="signupAddress" placeholder="Enter your address">
            <label for="signupDob">Date of Birth:</label>
            <input type="date" id="signupDob">
            <button onclick="signup()">Sign Up</button>
        </div>
    </div>

    <script>
        function changeTab(tab) {
            if (tab === 'login') {
                document.getElementById('loginTab').classList.add('active');
                document.getElementById('signupTab').classList.remove('active');
                document.getElementById('loginForm').style.display = 'block';
                document.getElementById('signupForm').style.display = 'none';
            } else {
                document.getElementById('loginTab').classList.remove('active');
                document.getElementById('signupTab').classList.add('active');
                document.getElementById('loginForm').style.display = 'none';
                document.getElementById('signupForm').style.display = 'block';
            }
        }

        function login() {
            // Add your login logic here
            alert('Login button clicked!');
        }

        function signup() {
            // Add your signup logic here
            alert('Sign Up button clicked!');
        }
    </script>
</body>
</html>
`}
          ></Script>
        </div>
      </div>
    </div>
  )
}

export default Loginsignup
